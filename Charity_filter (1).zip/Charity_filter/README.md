python app.py

gcloud builds submit --tag gcr.io/dash-plotly-support/support --project=dash-plotly-support

gcloud run deploy --image gcr.io/dash-plotly-support/support --platform managed --project=dash-plotly-support --allow-unauthenticated