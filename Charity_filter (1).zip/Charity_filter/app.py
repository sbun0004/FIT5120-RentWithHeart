from dash import Dash, dcc, html, Input, Output
from plotly.express import data
import pandas as pd
import re
import dash_bootstrap_components as dbc
import mysql.connector
from dash.dependencies import Input, Output, State



# Reading Data File
cnx = mysql.connector.connect(
    host='rentwithheart.cnjvip74ecit.ap-southeast-2.rds.amazonaws.com',
    user='admin',
    password='chilluaparna',
    database='rent_with_heart'
)

query = "SELECT * FROM data_charity"
data = pd.read_sql(query, con=cnx)
cnx.close()

type_df = data[['Charity_Legal_Name', 'Advancing_Education', 'Promoting_or_protecting_human_rights',
                'Advancing_social_or_public_welfare', 'Children', 'Families', 'Females',
                'Financially_Disadvantaged', 'Males', 'People_at_risk_of_homelessness']]
type_df.loc[:, "Type"] = None

for index, row in type_df.iterrows():
    charity_type = [col for col, value in row.items() if ((col != "Charity_Legal_Name") and (str(value).strip() == "Y"))]
    type_df.loc[index, "Type"] = ", ".join(charity_type)
type_df = type_df[["Charity_Legal_Name", "Type"]]

data["inside_vic"] = data["State"].apply(
    lambda x: "Only Victorian support organisations" if x in [
        'Victoria', 'VIC', 'Vic', 'victoria', 'St Helena Victoria', 'VICTORIA', 'Benalla Victoria',
        'vic', 'Victoria,', 'VIC ', 'Victora'
    ] else "Support organisations that operate across Australia including Victoria")
data = data[['Charity_Legal_Name', 'Charity_Website', 'Town_City', 'State', 'email', 'contact', 'inside_vic']]

final_df = pd.merge(data, type_df, on = "Charity_Legal_Name", how = "inner")

final_df["Charity_Website"] = final_df.apply(lambda x: "https://www." + str(x["Charity_Website"]).lower().replace("http://", "").replace("https://", "").replace("www.", "") if(len(x["Charity_Website"]) > 0) else ''
                                             , axis = 1)

type_dropbox = ['Advancing_Education', 'Promoting_or_protecting_human_rights','Advancing_social_or_public_welfare', 
                'Children', 'Families', 'Females','Financially_Disadvantaged', 'Males', 'People_at_risk_of_homelessness']

#Webpage HTML
app = Dash(__name__ , external_stylesheets=[dbc.themes.FLATLY])
server = app.server

app.layout = html.Div(style={'backgroundColor': '#EAE8DC'}, children= [

    html.Br(),
    html.H3('Select your location preference for the Support organisation', style = {'textAlign':'center'}),
    html.P('''Please note that all the organisations given below operate in Victoria. 
           There are some support service organisations that are based on the other states of Australia, 
           but all of them operate in Victoria remotely. All the organisation details that you see, operate in 
           Victoria, Australia.''', style = {'margin-left': '10%', 'width': '80%', 'textAlign':'center'}),
    
    html.Br(),
    html.H4('Please enter your preferred support organisation:', style = {'textAlign':'center'}),
    dcc.RadioItems(
        id='radio-filter',
        options=[{'label': i, 'value': i} for i in data['inside_vic'].unique()],
        value = data['inside_vic'].unique()[0],
        labelStyle={'display': 'inline-block', 'margin-right': '20px'},
        inputStyle={'margin-right': '10px'},
        style = {'textAlign':'center'}
    ),
    
    html.Br(),
    html.H4('Select from the given Suburbs:', style = {'textAlign':'center'}),
    dcc.Dropdown(
        id='dropdown-filtered',
        options=[],
        value=None,
        multi = True,
        style={'margin-left': '15%', 'width': '70%'}
    ),
    
    html.Br(),
    html.H4('Select Type of Support:', style = {'textAlign':'center'}),
    dcc.Dropdown(
        id='dropdown-support',
        options=[{"label":i, "value":i} for i in type_dropbox],
        value=None,
        multi = True,
        style={'margin-left': '15%', 'width': '70%'}
    ),
    
    html.Br(),
    html.Div(id='df-output', style={'width': '90%', 'border': 'solid', 'border-width': '2px', 'border-collapse': 'separate', 'margin-left':'5%'}),
    html.Br(),
    html.Br()
])

@app.callback(
Output('dropdown-filtered', 'options'),
[Input('radio-filter', 'value')]
)
def update_dropdown(radio_value):
    if(radio_value == "Only Victorian support organisations"):
        filtered_data = final_df[final_df['inside_vic'] == radio_value]
    else:
        filtered_data = final_df.copy()

    list_of_suburbs = sorted([str(suburb) for suburb in filtered_data["Town_City"].unique()])
    options = [{'label': str(suburb), 'value': str(suburb)} for suburb in list_of_suburbs]
    return options

@app.callback(
Output('df-output', 'children'),
[Input('dropdown-filtered', 'value'),
 Input('dropdown-support', 'value')]
)

def update_table(filtered, support):
    if(filtered):
        filtered_df = final_df[final_df["Town_City"].isin(filtered)]
    else:
        filtered_df = final_df.copy()
    
    if(support):
        filtered_df = filtered_df[filtered_df["Type"].str.contains('|'.join(support))]
    
    table_df = pd.DataFrame(columns = ["Name", "Website", "Type", "E-mail", "Phone number"])
    for index, row in filtered_df.iterrows():
        table_df = pd.concat([table_df, pd.DataFrame({"Name": [row['Charity_Legal_Name']],
                                                      "Website": [row['Charity_Website']],
                                                      "Type": [row["Type"]],
                                                      "E-mail": [row['email']],
                                                      "Phone number": [row['contact']]}
                                                     )], ignore_index=True)
    table_data = [html.Tr([html.Th(col, style={'width':'27%', 'padding': '10px', 'border-bottom': '2px solid black'}) for col in table_df.columns])] + \
                 [html.Tr([html.Td(table_df.iloc[i][col], style={'padding': '10px'})  if col != "Website" else html.Td(dcc.Link(table_df.iloc[i][col], href = table_df.iloc[i][col], target='_blank')) for col in table_df.columns])
                  for i in range(len(table_df))]

    return table_data


if __name__ == '__main__':
    app.run_server(debug=False, host="0.0.0.0", port=8080)
    #, host ="0.0.0.0", port=8080)